/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
class printTable extends Thread{
    private int num;
    private static Lock lock=new ReentrantLock(true);
   // private int times;
    
    public void run(){
        
            lock.lock();
    try{
              for(int i=1;i<=10;i++){
                      System.out.println(num+"*"+i+"="+num*i);
                      try{ sleep(100);} catch(InterruptedException e){
                                        System.out.println(e);
                      }                  }
        }
        finally{
            lock.unlock();
        }
        
        
    }
    public printTable( int num){
        this.num=num;
    }
}
public class Main
{
	public static void main(String[] args) {
	    Runnable pt;
	    Thread  thread;
	    //thread1.start();
	    for(int i=0;i<5;i++){
	        pt=new printTable(i+2);
	        thread= new Thread(pt);
	        thread.start();
	    }
	        
	    
		System.out.println("Hello World");
		/// two threads one is generation table of 2 and another table of 3
		
	}
}
