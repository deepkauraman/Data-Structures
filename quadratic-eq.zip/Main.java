/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		// for quadratic equation 
	  double a,b,c;
		System.out.println("enter a, b,c ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextDouble();
		b=sc.nextDouble();
		c=sc.nextDouble();
		double d;
		d=Math.pow(b,2)-4*a*c;
		double r1,r2;
		if(d>=0){
		r1=-b+Math.sqrt(d)/(2*a*c);
		r2=-b-Math.sqrt(d)/(2*a*c);
		 System.out.println("d ="+d+" r1:   " +r1+" r2 :" +r2);   
		}
		else {
		    System.out.println("imaginary roots");
		}
		
	}
}
