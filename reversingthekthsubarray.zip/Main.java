/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int arr[]= new int[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18};
		System.out.print("Enter the value of k");
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt();
		int i=0;
		int	n=arr.length;
	int step=0;
	//System.out.println("the value of array is"+n);
	//int counter=0;
		while(i<arr.length){
	//	    System.out.println(arr[i]);
		  
		    if(n>k)
		    {step=k;}
		    else{
		       step=n; 
		    }
		    for(int j=0,count=step-1;j<step/2;j++,count--){
		        // printing 
		        int temp=arr[j+i];
		        arr[j+i]=arr[i+count];
		        arr[i+count]=temp;
		        //System.out.println(arr[j+i]+"::::::"+);
		        //System.out.println(arr[j+i]+"\t"+arr[count+j+i]);
		        //reverse the entire sub  array
		        
		    }
		    n=n-k;
		    System.out.println("step="+n);
		    
		    i=i+k;
		}
		for(int c=0;c<arr.length;c++){
		    System.out.print(arr[c]+"\t");
		}
		
	
	}
	
}
