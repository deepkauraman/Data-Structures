import java.util.Scanner;

import javax.security.auth.x500.X500Principal;


public class Main{
  static StringBuilder c_ipt= new StringBuilder();
  static StringBuilder edata= new StringBuilder();
  static int key;
  static void decrpty(){
    System.out.print(edata);
    StringBuilder data=new StringBuilder();
    
    for(int i=0;i<edata.length();i++){
      char ch;
     
     if(Character.isUpperCase(edata.charAt(i))){
        int remainder=(int)edata.charAt(i)-key-65;
           if(remainder<0){
      int sol=(remainder-(remainder*26))%26+65;
      ch=(char)sol;
                    }
      else{
       int sol=remainder+65;
       ch=(char)sol;
      }

         
      }
       else{
           int rem=  (int)edata.charAt(i) -key - 97;
           if (rem<0){
               int sol=(rem-(rem*26))%26+97;
               ch=(char)sol;
           }
           else{
              int sol= rem+97;
              ch=(char)sol;
           } 
      }
      data.append(ch);
    }

    System.out.print("The data is "+data);
  }
  static StringBuilder encrypt(){
    System.out.print("Enter the i/p");
    Scanner sc=new Scanner(System.in);
    String ip=sc.nextLine();
    c_ipt.append(ip);
    System.out.print(c_ipt);
    //accessing the c_ipt
    /*for( int i=0;i<c_ipt.length();i++){
      System.out.print(c_ipt.charAt(i));
    }*/
    // now let us get a key
    System.out.print("Enter a key");
    
    key=sc.nextInt();
    StringBuilder result=new StringBuilder();
   for( int i=0;i<c_ipt.length();i++){
     char ch;
            if(Character.isUpperCase(c_ipt.charAt(i))){
      ch=(char)(((int)c_ipt.charAt(i)+key-65)%26+65);
        }
      else{
       ch= (char)(((int)c_ipt.charAt(i) +
       key - 97) % 26 + 97);
      }
      result.append(ch);
  }
   return result;
  }
    public static void main(String[] args) {
    
    ///StringBuilder eipt=new StringBuilder();
    
    edata=encrypt();
    decrpty();
    
  

  }
  
}

