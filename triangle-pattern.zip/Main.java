public class main {
  static void  printtri(int n){
    //int n=7;
    int rows=n/2+1;
    int counter=0;
    for (int i=1;i<=rows;i++){
      for(int space=rows-i;space>=1;space--){
          System.out.print(" ");
        }
        for(int j=1;j<=(i+counter);j++){
          System.out.print("*");
        }
        counter++;
        System.out.println(" ");
      }
  }
  static void  printinverse(){
    int n=7;
    int rows=n/2+1;
    int counter=0;
    for(int i=1;i<=rows;i++){
      for(int space=1;space<i;space++)
      {
        System.out.print(" ");
      }
      for(int j=1;j<=n-counter;j++){
        System.out.print("*");

      }
      counter=counter+2;
      System.out.println();
    }


  }
  static void printlefttri(){
    int n=5;
    int col=n/2+1;
    for( int i=1;i<=n;i++){
      if(i<=col){
      //System.out.print(i+" ");
      for( int j=i;j>=1;j--){
        System.out.print("*");
      }
      }
      else{
        for( int j=n-(i-1);j>=1;j--){
          System.out.print("*");
        }
      }
      System.out.println();
    }

  }
  static void printrighttri(int rows){
    int col=rows/2+1;
    for(int i=1;i<=rows;i++){
      if(i<=col){
      for(int space=i+1;space<=col;space++){
        System.out.print(" ");
      }
      for(int j=1;j<=i;j++){
        System.out.print("*");
      }
    }
    else{
      for(int space=0;space<=i-col;space++){
        System.out.print(" ");
      }
      for(int j=1;j<=rows-i;j++){
        System.out.print("*");
      }

    }
    System.out.println();


    }

  }
  public static void main(String[] args) {
    //where n is representing columns
    int n=7;
    int rows=n/2+1;
    int counter=0;
    for (int i=1;i<=rows;i++){
      for(int space=rows-i;space>=1;space--){
          System.out.print(" ");
        }
        for(int j=1;j<=(i+counter);j++){
          System.out.print(j);
        }
        counter++;
        System.out.println(" ");
      }

      printtri(9);
      System.out.println("-------------------------------");
      printinverse();
      System.out.println("--------------------------");
      printlefttri();
      System.out.println(" -----------------");
      printrighttri(7);
    }
  }
  

