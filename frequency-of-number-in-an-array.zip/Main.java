public class Main {
  public static void main(String args[]){
    int [] a= new int[]{2};
    int i=1;
    int freq=1;
    int n=a.length;
   System.out.println(n);
   // in this logic last element will not be taken into consideration
   /*for(i=0;i<n-1;i++)
   {   
       //System.out.println(a[i]+"::"+a[i+1]);
       if(a[i]==a[i+1]){
           freq+=1;
           continue;
           
       }
       
           System.out.println(a[i]+":"+freq);
           freq=1;
       
       
   }*/
   while(i<n){
       while(i<n && a[i]==a[i-1]){
           //System.out.println(a[i]);
           freq++;
           i++;
       }
       System.out.println(a[i-1]+":"+freq);
       i++;
       freq=1;
   }
  if(n==1 ||a[n-1]!=a[n-2]){
      System.out.println(a[n-1]+":"+1);
  }
  }
}
