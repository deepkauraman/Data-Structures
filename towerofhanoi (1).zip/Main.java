/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{   public static void toi(int n,char src,char des,char aux){
    if (n==0) return ;
    else 
    toi(n-1,src,aux,des);
      System.out.println(n+"["+src+"->"+des+"]");
    toi(n-1,aux,des,src);
  
}
	public static void main(String[] args) {
		int num_tower=3;
		int n=3;
		char src='a';
		char des='b';
		char aux='c';
		toi(n,src,des,aux);
	}
}
