public class Main {
  public static void main(String arg[]){
    int ar[]=new int[]{1,1,1,1,1};
    int pc=0;
    int c=0;
    for(int i=0;i<ar.length;i++){
      if(ar[i]==1){
        while(i<ar.length && ar[i]==1  ){
        c=c+1;
        //System.out.println(c+":"+ar[i]+"::"+i);
          i++;
        }
      }
      if(c>=pc)
      {pc=c;
      c=0;
      }


    }
    
    System.out.print(pc);
  }
  
}
