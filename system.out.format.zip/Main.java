/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
    final float pi=3.1494544f;
    final float nv=3.3f;
    System.out.format("%f",pi);
     System.out.println();
    System.out.format("%.2f",pi);
    System.out.println();
      System.out.format("%20.2f",pi);
    System.out.println();
     System.out.format("%20.2f",pi);
    System.out.println();
     System.out.format("%+20.2f",pi);
       System.out.println();
         System.out.println();
      // accessing second element first   
      System.out.format("%2$+20.2f %1$+04.5f",pi,nv);
  

   	
	}
}
