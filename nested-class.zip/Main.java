/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class outer{
    static private  int a;
     static class nested{
         int c=40;
        void printouter(){
            a=10;
            
            System.out.println(a);
        }
    }
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		outer ob=new outer();
		outer.nested o= new  nested();
		o.printouter();
	//	ob.printouter();
	
	}
}
