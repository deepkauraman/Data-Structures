public class stockandbuy {
  public static void main(String ar[]){
    int profit[]= new int[]{6,7,5,4};
    int res=0;
    int c=profit[0];
    for(int i=1;i<profit.length;i++){
      System.out.println(c+": "+profit[i]);
      if(profit[i]<profit[i-1]){
       
        c=profit[i];
      }
      else{
        res=res+profit[i]-profit[i-1];
      }

    }
    System.out.print(res);
    

  }
  
}
