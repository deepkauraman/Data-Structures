/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
    static void printleftarrow(int n){
        int mid=(n/2)+1;
        for(int row=1;row<=n;row++){
            if(row<mid){
                for(int space=1;space<=mid-row;space++){
                    System.out.print(" ");
                }
                for(int sp=1;sp<=row;sp++){ System.out.print("*"); }
                
            }
            
            if(row==mid){
                for(int i=1;i<=n;i++){
                    System.out.print("*");
                }
            }
            
            if(row > mid){
                   
                   for(int space=1;space<=row-mid;space++)
                   {
                    System.out.print(" ");
                    }
                for(int sp=row;sp<=n;sp++)
                {
                    System.out.print("*");
                    
                }
                
            }
            
        
        
        
            System.out.println();
        }
    }
        
    

        
	public static void main(String[] args) {
		//System.out.println("Hello World");
		printleftarrow(7);
	}
}

