/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main
{   public static int[] toallindices(int[] arr, int target,int idx, int count ){
     if(idx==arr.length){
         int[] base= new int[count];
         return base;
     }
     if(arr[idx]==target){
         int []res=toallindices(arr,target,idx+1,count+1);
         res[count]=idx;
         return res;
     }
     else{
         int res[]=toallindices(arr,target,idx+1,count);
         return res;
     }
    
    
    
}
	public static void main(String[] args) throws IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	int n=Integer.parseInt(br.readLine());
     int[] arr=new int[n];
     
     for(int i=0;i<n;i++){
         arr[i]=Integer.parseInt(br.readLine());
     }
     
     System.out.println("Enter the target value");
     int x=Integer.parseInt(br.readLine());
     int res[]=toallindices(arr,x,0,0);
     
     
     
     
          for( int i=0;i<res.length;i++){
         System.out.print(res[i]+"\t");
     }
	}
}
