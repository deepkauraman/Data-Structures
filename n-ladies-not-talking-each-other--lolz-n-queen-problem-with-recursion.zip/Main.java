/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
    static int n=6;
static int[][] chessboard=new int[n][n];
//static int count=0;

    static  void printchess()
    {
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                System.out.print(chessboard[i][j]+"\t");
            }
            System.out.println("\n");
        }
       
    }
static boolean  solve(){
    if(solveRec(0)==false){
        return false;
    }
    else{
        printchess();
        return true;
    }
    
}

 static boolean solveRec(int col){
     if(col==n){
         //System.out.print(count+" ");
         return true;
     }
     for( int i=0;i<n;i++)
     {
     
      if(isSafe(i,col))
        {
            chessboard[i][col]=1;
                if(solveRec(col+1)){
                    return true;
                }
            chessboard[i][col]=0;
         
        }
         
     }
     
     return false;
     
 }
 static boolean isSafe(int row,int col){
     // check same row from left to the specific column
     for(int i=0;i<col;i++){
         if(chessboard[row][i]==1){
             return false;
             // means their is a queen in the row;
         }
         
     }
     // check diagonals
     
     for(int i=row,j=col;i>=0&j>=0;i--,j--){
         if(chessboard[i][j]==1){return false;}
         
     }
     //checking diagonals
     for(int i=row,j=col;j>=0 &&i<n;i++,j--){
         if(chessboard[i][j]==1){return false;}
     }
     return true;
 } 
    
	public static void main(String[] args) {
	    solve();
		}
}
