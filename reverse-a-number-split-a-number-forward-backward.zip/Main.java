/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
// count the digits and reverse a number and then print according to place value
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int temp=num;
		int count=0;
		while(temp>0){
		    temp=temp/10;
		    count++;
		}
		count--;
		System.out.println(count);
		int number=num;
		while(number>0 || count >=0){
		//    System.out.println("num"+number);
		  int   po=(int)Math.pow(10,count);
		    System.out.println(number/po+"\t");
		    number=number%po;
		    count--;
		}
		System.out.println(" ");
	   int rev=num;
	   while(rev>0){
	    System.out.println(rev%10+"\t");
	    rev=rev/10;
	   }
	}
}
