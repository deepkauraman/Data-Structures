/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{  
    public static boolean issorted(int arr[])
    { 
        for(int i=1;i<arr.length;i++){
            if(arr[i]<arr[i-1]){
                return false;
            }
        
    }
    
   return true;
     

     }
	public static void main(String[] args) {
		System.out.println("Hello World");
		int arr[]=new int[]{200,30,50,60,80};
		System.out.print(issorted(arr));
	}
}

