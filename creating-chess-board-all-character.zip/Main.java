/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// king's move  moving one step from the given position
public class Main
{
    static int n=8;
    static int[][] cb=new int[n][n];
    static boolean kingmove(int row,int col){
        //king can move one in any directions;
        if(row>0 && row<7) &&(col>0 and col<7){
            cb[row-1][col]=1;
            cb[row-1][col-1]=1;
            cb[row-1][col+1]=1;
            cb[row+1][col]=1;
            cb[row+1][col+1]=1;
            cb[row+1][col+1]=1;
            cb[row][col-1]=1;
            cb[row][col+1]=1;
        
            
        }
        if(row==0){
            cb[row+1][col]=1;
            cb[row+1][col+1]=1;
            cb[row+1][col+1]=1;
            cb[row][col-1]=1;
            cb[row][col+1]=1;
        
            
        }
        if(row==7){
            cb[row-1][col]=1;
            cb[row-1][col-1]=1;
            cb[row-1][col+1]=1;
            
        }
        
        
        
    }
    public static void main(String[] args)
    {
        Scanner sc=new scanner(System.in);
        System.out.println("Enter the King's position on chess board of 8*8 interms of indexes starting from 00");
        kprow=sc.nextInt();
        kpcol=sc.nextInt()
        kingmove(kprow,kpcol);
		
	}
	
}
