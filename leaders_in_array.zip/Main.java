/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		// finding leaders in ArrayStoreException
		int a[]={1,2,3,40,5,5,2,7,1};
		//o/p= {1,7,40}
		int cl;
		cl=a.length-1;
		if(cl>=0){
		    System.out.print(a[cl]+"\t");
		}
		for(int i=a.length-2;i>=0;i--){
		    if(a[i]>a[cl]){
		        cl=i;
		    System.out.print(a[cl]+"\t");
		    }
		}
	}
}
