/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
class Main
{
	public static void main(String[] args) {
		 //hollow diamonds
		 int row=9;
		 int i,k,j;
		 int rownum=row/2;
		 for(i=1;i<=row/2+1;i++)
		 { 
		     for(k=1;k<row/2+2-i;k++){
		         System.out.print(" ");
		     }
		     System.out.print("*");
		     for(j=0;j<row-(2*k);j++){
		     System.out.print(" ");
		     }
		     if(j==0){
		         System.out.println();
		         
		     }
		     else{
		         System.out.println("*");
		     }
		     
		 }
		 
		 // bottom half 
		  for(i=row/2+2;i<=row;i++)
		 { 
		     for(k=1;k<=i-((row/2)+1);k++)
		     {
		         System.out.print(" ");
		     }
		     System.out.print("*");
		     
		     // inner space
		     for(j=0;j<row-2*k;j++){
		         System.out.print(" ");
		     }
		      if(i==row)
		     {
		         System.out.println();
		     }
		     else
		     {
		         System.out.println("*");
		     }
		    
		 }
		     
	}
	
}
