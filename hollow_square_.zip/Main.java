/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
    static void printpattern(int col){
       int rows=col-2;
      int  mid=rows/2+1;
      int midcol=col/2+1;
      int counter=1;
        for(int irow=1;irow<=mid;irow++)
        {   
            for(int i=1;i<=midcol-counter;i++){
                System.out.print("*\t");
            }
            
            for(int space=1;space<=col-2*(midcol-counter);space++){
                System.out.print("\t");
            }
            for(int i=1;i<=midcol-counter;i++){
                System.out.print("*\t");
            }
            counter=counter+1;
            System.out.println();
    }
    //inverted 
    counter-=1;
   
     for(int irow=mid+1;irow<=rows;irow++){
         
        int lcol=(col-counter)/2;
       int rcol=(col-counter)/2;
         for(int i=1;i<=lcol;i++){
             System.out.print("*\t");
         }
         for(int space=1;space<=col-(2*lcol);space++){
             System.out.print("\t");
         }
         for(int i=1;i<=lcol;i++){
             System.out.print("*\t");
         }
         counter=counter-2;
             
         System.out.println();
     }
    
    
    }
	public static void main(String[] args) {
	printpattern(7);
	    
	}
	
}
