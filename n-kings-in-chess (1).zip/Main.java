/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

has to edited Nkings 
*******************************************************************************/
public class Main
{   static int n=4;
    static int[][] cb=new int[n][n];
    static void printcb()
    {
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                System.out.print(cb[i][j]+" \t");
            }
        
            System.out.println(" ");
        }
    }
    static boolean solveRec(int col)
    {
        
        if(col==n){return true;}
        for(int i=0;i<n;i++){
            if(isSafe(i,col)){
                //System.out.println("hell");
                cb[i][col]=1;
                if(solveRec(col+1)) return true;
                cb[i][col]=0;
            }
        }
        
        return false;
    }
    
    static boolean isSafe(int row,int col){
                  if(row>0 &&row<7 && col>0 &&col<7){
            if((cb[row-1][col]==1)||(cb[row+1][col]==1)||(cb[row+1][col-1]==1)||(cb[row-1][col-1]==1)||(cb[row][col-1]==1)){
                return false;
            }
        } 
        if(row==0)
          {
              if(col==0){
                  if((cb[row+1][col]==1)){return false;}
                  
              }
              else if(col==n-1){
                  if((cb[row][col-1]==1)||(cb[row+1][col-1]==1)||(cb[row+1][col-1]==1)){return false;}
              }
          }
          
          if(row==n-1){
                if(col==0){
                  if((cb[row-11][col]==1)||(cb[row-1][col+1]==1)||(cb[row][col+1]==1)){return false;}
                  
              }
              else if(col==n-1){
                  if((cb[row-1][col-1]==1)||(cb[row-1][col-1]==1)||(cb[row-1][col]==1)){return false;}
              }
          }
              
          
        return true;
    }
    static boolean solve()
    {
        if(solveRec(0)==false)
        {
            return false;
            
        }
        else
        {
            printcb();
            return true;
        }
    } 
	public static void main(String[] args) {
	    solve();
		
	}
}

