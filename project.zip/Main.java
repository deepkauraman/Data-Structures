/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Timer;
import java.util.TimerTask;
//class helper extends TimerTask

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int x=299;
		int [] arr=new int[300];
		for( int i=0;i<300;i++){
		    arr[i]=i;
		}
	
		long startTime=System.nanoTime();
		
		for(int i=0;i<300;i++){
		   if(arr[i]==x){
		       break;
		   }
		   System.out.print(i);
		}
		long endTime=System.nanoTime();
		long TimeDiff=(endTime-startTime);
		double duration=(TimeDiff/1000000.0);
		System.out.println("***************\n"+duration);
	}
}
