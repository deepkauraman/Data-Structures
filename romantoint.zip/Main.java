/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
     static int getVal(char ch){
           switch(ch){
                case 'I':
                    return 1;
                    
                case 'V':
                    return 5;
                case 'X':
                    return 10;
                case 'L':
                    return 50;
                case 'C':
                    return 100;
                case 'M':
                    return 1000;
                case 'D':
                    return 500;
                default : return 0;
            
            }
        //    return 0;
     }
    static void convert(String s){
         final int I=1;
         final int C=100,v=5,x=10,L=50,M=1000;
         char fsym,ssym;
         int val1;
         int val2=0;
         int sum=0;
         boolean check=true;
        for(int i=0;i<s.length();i++)
                { 
                     fsym=s.charAt(i);
                     val1=getVal(fsym);
                     
                    if(i+1<s.length()){
                                  
                     ssym=s.charAt(i+1);
                     
                     val2=getVal(ssym);
                        if(val1>= val2){sum=sum+val1;  }
            else{
                sum=sum+val2-val1;
                i++;
                
            }
                        
                    }// if 
                    else{
                        sum=sum+val1; }
                
            }
            
            System.out.println(sum);
            
    }
            
           
    
	public static void main(String[] args) {
		System.out.println("Hello World");
		convert("XXVII");
		convert("MCMIV");
	}
}

