/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{ 
    static void downarrow(int n){
        int mid=(n/2)+1;
        for(int row=1;row<mid;row++){
            for(int col=1;col<mid-1;col++)
               {
                   System.out.print(" ");
               }
               System.out.println("*");
            
        }
        int k=1;
        
        for(int row=mid;row<=n;row++){
            for(int space=1;space<k;space++){
                System.out.print(" ");
            }
             for(int col=1;col<=n-2*k;col++){
                System.out.print("*"); 
             }
             k++;
             System.out.println(" ");
        }
            
        
        
    }
    
	public static void main(String[] args) {
		downarrow(9);
	}
}
