/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main

{
      static void printI(int n){
    for(int i=0;i<n;i++){
      System.out.print("*");
    }
    System.out.println("");
    for(int j=1;j<n;j++){
    for(int i=0;i<n/2;i++){
      System.out.print(" ");

    }
    System.out.println("*");
  }
  for(int i=0;i<n;i++){
    System.out.print("*");
  }
    

  }

  static void printT(int n){
    for(int i=0;i<n;i++){
      System.out.print("*");
    }
    System.out.println("");
    for(int j=1;j<n;j++){
    for(int i=0;i<n/2;i++){
      System.out.print(" ");

    }
    System.out.println("*");
  }
    }

    static void printH(int n){
      for(int i=0;i<n/2;i++){
        System.out.print("*");
        for(int j=1;j<n;j++){
          System.out.print(" ");
        }
        System.out.println("*");
      }
      ///System.out.println("");
      for(int i=0;i<=n;i++){
        System.out.print("*");

      }
      System.out.println("");
      for(int i=n/2+1;i<n;i++){
        System.out.print("*");
        for(int j=1;j<n;j++){
          System.out.print(" ");
        }
        System.out.println("*");
      }

    }

    static void printM(int n){
    // for upper half
        for(int i=0;i<n/2;i++){
        System.out.print("*");
            for(int space=0;space<i;space++){
            if(space==i-1){
            System.out.print("*");
          }
          else{
          System.out.print(" ");}
        }
        for(int j=1;j<n-(2*i);j++){
          System.out.print(" ");
        }
        
        for(int space=n-i;space<n;space++){
          if(n-space==i){
            System.out.print("*");
          }
          else{
            System.out.print(" ");
          }
        }

        System.out.println("*");


      }
    
    
    
    
    
    
    
    
    
    
    
    
      
    // for exactly center
    //System.out.print("___");
    System.out.print("*");

    for( int i=0;i<=n-2;i++)
    {
        //System.out.print(i);
    if(i==(n-1)/2){
      System.out.print("*");
    }
    else{
      System.out.print(" ");
    }

    }
    System.out.println("*");

    // for the lower half
    for(int lh=n/2+1;lh<n;lh++)
    {
      System.out.print("*");
      for(int j=1;j<n;j++){
        System.out.print(" ");
      }
      System.out.println("*");
    }

    }


	public static void main(String[] args) {
		System.out.println(""); 
	
	   printH(7);
	   System.out.println("");
	   printT(5);
	   System.out.println("");
	   printI(7);
	   System.out.println("");
		printM(9);
		
	}
}
