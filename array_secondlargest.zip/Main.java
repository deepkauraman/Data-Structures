/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int arr[]=new int[]{10,2,30,-4,95,60,7}; 
		// find the second largest 
		int max=0;
		int res=-1;
		for(int i=1;i<7;i++){
		    if(arr[i]>arr[max]){
		        res=max;
		        max=i;
		    }
		    else if(arr[i]!=arr[max]){
		        if(res==-1 ||arr[i]>arr[res]){
		            res=i;
		        }
		    }
		    
		}
		System.out.println(arr[max]+":"+arr[res]);
	}
}
