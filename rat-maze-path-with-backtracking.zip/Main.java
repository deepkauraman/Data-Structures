/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
static int[][] sol=new int[10][10];
static int[][] maze =new int[10][10];
static int row;
static int col;

    static  void printMaze(){
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                System.out.print(maze[i][j]+"\t");
            }
            System.out.println("\n");
        }
        System.out.println("***************************");
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                if(sol[i][j]==0){
                    System.out.print("\t");
                }
                else{
                System.out.print(sol[i][j]+"\t");}
            }
            System.out.println("\n");
        }
    }
    
    static boolean isSafe(int i, int j){
        return (i<row && j< col && maze[i][j]==1);
        
    }
    static boolean solveMazeRec(int i,int j)
    {
        if(i==row-1 && j==col-1){
            sol[i][j]=1;
            return true;
        }
        
        if(isSafe(i,j)==true)
        {
            sol[i][j]=1;
            
            if(solveMazeRec(i+1,j)==true){
                return true;
            }
            else if(solveMazeRec(i,j+1)==true){
                return true;
                
            }
            sol[i][j]=0;
        }
        
        
        
        
        return false;
    
    }
    static boolean solveMaze(int n,int m){
        
        if(solveMazeRec(0,0)==false){
            return false;
        }
        else{
            
            System.out.println("The path that the rat will follow to take cheese");
            printMaze();
            return true;}
        
    }
	public static void main(String[] args) {
		// print rats path and get the path// given a matrix as an i/p and print the path as an output
		Scanner sc=new Scanner(System.in);
		//int row;
		//int col;
		System.out.println("Enter the row");
			 row=sc.nextInt();
		System.out.print("Enter the col");
	 col=sc.nextInt();
		    System.out.println("Enter the boolean matrix");
    
		for(int i=0;i<row;i++){
		    for(int j=0;j<col;j++)
		    {
		        maze[i][j]=sc.nextInt();
		    }
		}
		solveMaze(0,0);
		
	}
}
