/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    static void  uparrow(int n){
        int mid=(n/2)+1;
        int k=mid-1;
        for(int row=1;row<=mid;row++){
            for(int space=1;space<=k;space++){
                System.out.print(" ");
            }
            for(int sp=1;sp<=n-2*k;sp++){
                System.out.print("*");
            }
            System.out.println(" ");
            k--;
             
        }
        for(int row=1;row<mid;row++){
            for(int col=1;col<mid;col++)
            {
                System.out.print(" ");
            }
            System.out.println("*");
        }
        
        
    }
    
	public static void main(String[] args) {
		uparrow(7);
	}
}
