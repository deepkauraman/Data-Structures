/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		//removing duplicates in a sorted Array
		int arr[]=new int[]{2,3,4,5,6,6,78,78};
		int temp[]=new int[8];
		temp[0]=arr[0];
		int k=0;
        for(int i=1;i<arr.length;i++){
            if(temp[k]!=arr[i]){
                k++;
                temp[k]=arr[i];
            }
            
        }
        int a[]=new int[]{10,20,20,20,30,40,40,50};
        int res=1;
        for(int i=1;i<a.length;i++){
            if(a[i]!=a[res-1]){
                a[res]=a[i];
                res++;
            }
        }
        
        for(int i=0;i<=res;i++){
            System.out.println(a[i]);
        }    
        for(int i=0;i<=k;i++){
            System.out.println(temp[i]);
        }    
            
        	    
	}
}
