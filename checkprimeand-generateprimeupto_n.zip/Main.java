/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
// check whether a given number is prime or not! and priniting  prime numbers upto n
import java.util.*;
import java.lang.*;
public class Main
{
    static void generateupto(int n){
        int i=4;
        if(n>1){
            
        if(n>=3){
               // System.out.println("1");
            System.out.println("2");
            System.out.println("3");
        }
        if(n==2){
           // System.out.println("1");
            System.out.println("2");
                }
        
        while(i<=n){
            checkprime(i);
            i++;
        }
        
    }// if n is greater than 0
    }
    static void checkprime(int n){
        boolean isprime=true;
        for(int i=2;i<=Math.sqrt(n);i++){
            if(n%i==0){
                //System.out.println("Not a prime number");
                isprime=false;
            }
            
        }
        if(isprime==true){
            System.out.println(n);
        }
    } 
	public static void main(String[] args) {
		System.out.println("Hello World");
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		checkprime(n);
		generateupto(n);
	}
}
