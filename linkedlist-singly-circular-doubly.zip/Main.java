/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.io.*; 
class Node{
    int data;
    Node next;
    Node(int x){
        data=x;
        next=null;
    }
}
class DNode{
    int data;
    DNode next;
    DNode prev;
    DNode(int x){
        data=x;
    }
}
public class Main

{
    
    static void traverse(Node head){
        Node curr=head;
        while(curr!=null){
        System.out.println(curr.data );
            curr=curr.next;
        }
    }
    
    static Node iAtBeg(Node head,int val){
        Node temp=new Node(val);
        if(head==null){
            return temp;
        }
        temp.next=head;
        return temp;
    }
    
    static Node iAtLoc(Node head,int loc,int val){
        Node curr=head;
        int count=0;
        while(curr!=null){
            count++;
            curr=curr.next;
                    }
                    if(count<loc){
                        return null;
                    }
                    else{
                        curr=head;
                        for(int i=0;i<loc;i++){
                            curr=curr.next;
                            
                        }
                        Node temp=new Node(val);
                        temp.next=curr.next;
                        curr.next=temp;}
    
                     return head;   
                    }
    
    static Node iAtEnd(Node head, int val){
        Node temp=new Node(val);
        Node curr=head;
        if(head==null){
            return temp;
        }
        while(curr.next!=null)
        {
            curr=curr.next;
            
        }
        curr.next=temp;
        return head;
    }
    
    static Node DelAtBeg(Node head){}
    static Node DelAtMiddle(Node head){}
    static Node DelAtEnd(Node head){}
    
    
	public static void main(String[] args) {
		
		 System.out.println(" press 1 for singly linked list");
		 System.out.println("press 2 for Doubly Linked List");
		 System.out.println("press 3 for Circular Linked List");
		  int ch;
		  Scanner sc=new Scanner(System.in);
		  ch=sc.nextInt();
		  switch(ch){
		      case 1:{
		          // create a singly linked list
		          
		 Node head=new Node(10);
		 head.next= new Node(20);
		head.next.next= new Node(30);
		traverse(head);
		System.out.println("Enter the value to be inserted at begining");
        int val;
        val=sc.nextInt();
		head=iAtBeg(head,val);
		traverse(head);
		System.out.println("Enter the value to be inserted at end");
        val=sc.nextInt();
		head=iAtEnd(head,val);
		traverse(head);
		      
		 System.out.println("Enter the value to be insert at a location , enter location and value");
                int loc;
        loc=sc.nextInt();
        val=sc.nextInt();

		head=iAtLoc(head,loc,val);
		  traverse(head);
		          break;
		      }
		      
		      
		      
		      case 2:{
		          break;
		      }
		      case 3:
		          break;
		  }
		 
		
	}
}
