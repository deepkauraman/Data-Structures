import java.util.*;
public class Main{
 static  char table[][]= new char[27][27];
 static StringBuffer data=new StringBuffer();
 static StringBuffer key= new StringBuffer();
 static  void tablecreation(){
    for(int i=1;i<27;i++){
        table[0][i]=(char)(64+i);
        table[i][0]=(char)(64+i);
    }
    table[0][0]=' ';
  int base=64;
  for(int i=1;i<27;i++){
    for(int j=1;j<27;j++){
       int baseval=(base+j)%91;
      if(baseval<65){
        baseval=baseval+65;
      }
    table[i][j]=(char)(baseval);}
    base++;
  }
  for(int i=0;i<27;i++){
    for(int j=0;j<27;j++){
    System.out.print(table[j][i]+" ");
  }
  System.out.println();
}

 }
 static void inputdata(){
   Scanner sc=new Scanner(System.in);
  System.out.print("Enter the data and key");
  
  data.append(sc.nextLine());
  key.append(sc.nextLine());
  // key generate
   int kl=key.length();
   int dl=data.length();
   StringBuffer kg=new StringBuffer();
   while(kg.length()<dl)
  { kg.append(key);}
  
   StringBuffer finalkey=new StringBuffer();
   finalkey.append(kg.substring(0,dl));
  
  //System.out.print("\n"+finalkey);
   
     
     encipher(finalkey); 
  
 }
 static void encipher(StringBuffer kg){
     //System.out.print("\n"+kg);
     StringBuffer ct=new StringBuffer();
     for(int i=0;i<kg.length();i++)
          {
              ct.append(table[((int)data.charAt(i)-65)+1][((int)kg.charAt(i)-65)+1]);
              //System.out.print(data.charAt(i)+" "+kg.charAt(i)+"\n");
         //System.out.print(((int)data.charAt(i))-65+" "+((int)kg.charAt(i))-65+"\n");
     }
     System.out.print(ct);
     
 }
  public static void main(String[] args) {
  tablecreation(); 
  inputdata() ;
  
  //System.out.print(data+" "+key);
  //System.out.print("\t\t"+data.length());
  // generating key of the same length;
  

  }
  
}
