/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{  static void permute(StringBuilder str,int i){
    //StringBuilder s=new StringBuilder();
    char s;
    if(i==str.length()-1){
        System.out.println(str);
        return;
    }
    for(int j=i;j<str.length();j++){
        s=str.charAt(i);
        str.setCharAt(i,str.charAt(j));
        str.setCharAt(j,s);
        permute(str,i+1);
        //System.out.println(str);
       s=str.charAt(i);
        str.setCharAt(i,str.charAt(j));
        str.setCharAt(j,s);
        
    }
}
	public static void main(String[] args) {
		System.out.println("Hello World");
		StringBuilder str= new StringBuilder("xyz");
		permute(str,0);
		
	}
}
