/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{  public static  class student {
    int age;
    String name;
    public  void announce(){
        System.out.print(this.age+this.name+" is getting announced");
    }
    
   }
   public static void swap(student s1, student s2){
      student temp;
      temp=s1;
      s1=s2;
      s2=temp;
    }
    public static void swapping(student s1,student s2){
        student temp =new student();
        temp.age=s1.age;
        s1.age=s2.age;
        s2.age=temp.age;
    }

	public static void main(String[] args) {
		student s;
		s=new student();
		
		s.age=10;
		s.name="aman";
		s.announce();
		
		student s2=new student();
		s2.age=20;
		s2.name="mani";
		s2.announce();
		 swap(s,s2);
		 System.out.println("after swap");
		 s.announce();
		 s2.announce();
		 System.out.println("after swapping");
		 swapping(s,s2);
		 s.announce();
		 s2.announce();
	}
}
